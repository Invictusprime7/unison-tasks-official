import { c as _c } from "react-compiler-runtime";
import * as React from 'react';
import { Box } from '../ink.js';
import type { AgentDefinitionsResult } from '../tools/AgentTool/loadAgentsDir.js';
import type { MemoryFileInfo } from '../utils/claudemd.js';
import { getMemoryFiles } from '../utils/claudemd.js';
import { getGlobalConfig } from '../utils/config.js';
import { getActiveNotices, type StatusNoticeContext } from '../utils/statusNoticeDefinitions.js';
type Props = {
  agentDefinitions?: AgentDefinitionsResult;
};

let cachedMemoryFiles: MemoryFileInfo[] = [];
let memoryFilesPromise: Promise<void> | null = null;

async function loadMemoryFiles(): Promise<void> {
  if (memoryFilesPromise) {
    return memoryFilesPromise;
  }
  memoryFilesPromise = getMemoryFiles().then(files => {
    cachedMemoryFiles = files;
  }).finally(() => {
    memoryFilesPromise = null;
  });
  return memoryFilesPromise;
}

/**
 * StatusNotices contains the information displayed to users at startup. We have
 * moved neutral or positive status to src/components/Status.tsx instead, which
 * users can access through /status.
 */
export function StatusNotices(t0) {
  const $ = _c(8);
  const {
    agentDefinitions
  } = t0 === undefined ? {} : t0;
  const [memoryFiles, setMemoryFiles] = React.useState(cachedMemoryFiles);
  let t1;
  if ($[0] === Symbol.for("react.memo_cache_sentinel")) {
    t1 = () => {
      if (cachedMemoryFiles.length > 0) {
        setMemoryFiles(cachedMemoryFiles);
        return;
      }
      void loadMemoryFiles().then(() => {
        setMemoryFiles(cachedMemoryFiles);
      });
    };
    $[0] = t1;
  } else {
    t1 = $[0];
  }
  React.useEffect(t1, [t1]);
  const t2 = getGlobalConfig();
  const context = {
    config: t2,
    agentDefinitions,
    memoryFiles
  };
  const activeNotices = getActiveNotices(context);
  if (activeNotices.length === 0) {
    return null;
  }
  const T0 = Box;
  const t3 = "column";
  const t4 = 1;
  const t5 = activeNotices.map(notice => <React.Fragment key={notice.id}>{notice.render(context)}</React.Fragment>);
  let t6;
  if ($[1] !== T0 || $[2] !== t5) {
    t6 = <T0 flexDirection={t3} paddingLeft={t4}>{t5}</T0>;
    $[1] = T0;
    $[2] = t5;
    $[3] = t6;
  } else {
    t6 = $[3];
  }
  return t6;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJSZWFjdCIsInVzZSIsIkJveCIsIkFnZW50RGVmaW5pdGlvbnNSZXN1bHQiLCJnZXRNZW1vcnlGaWxlcyIsImdldEdsb2JhbENvbmZpZyIsImdldEFjdGl2ZU5vdGljZXMiLCJTdGF0dXNOb3RpY2VDb250ZXh0IiwiUHJvcHMiLCJhZ2VudERlZmluaXRpb25zIiwiU3RhdHVzTm90aWNlcyIsInQwIiwiJCIsIl9jIiwidW5kZWZpbmVkIiwidDEiLCJ0MiIsIlN5bWJvbCIsImZvciIsImNvbnRleHQiLCJjb25maWciLCJtZW1vcnlGaWxlcyIsImFjdGl2ZU5vdGljZXMiLCJsZW5ndGgiLCJUMCIsInQzIiwidDQiLCJ0NSIsIm1hcCIsIm5vdGljZSIsImlkIiwicmVuZGVyIiwidDYiXSwic291cmNlcyI6WyJTdGF0dXNOb3RpY2VzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgQm94IH0gZnJvbSAnLi4vaW5rLmpzJ1xuaW1wb3J0IHR5cGUgeyBBZ2VudERlZmluaXRpb25zUmVzdWx0IH0gZnJvbSAnLi4vdG9vbHMvQWdlbnRUb29sL2xvYWRBZ2VudHNEaXIuanMnXG5pbXBvcnQgeyBnZXRNZW1vcnlGaWxlcyB9IGZyb20gJy4uL3V0aWxzL2NsYXVkZW1kLmpzJ1xuaW1wb3J0IHsgZ2V0R2xvYmFsQ29uZmlnIH0gZnJvbSAnLi4vdXRpbHMvY29uZmlnLmpzJ1xuaW1wb3J0IHtcbiAgZ2V0QWN0aXZlTm90aWNlcyxcbiAgdHlwZSBTdGF0dXNOb3RpY2VDb250ZXh0LFxufSBmcm9tICcuLi91dGlscy9zdGF0dXNOb3RpY2VEZWZpbml0aW9ucy5qcydcblxudHlwZSBQcm9wcyA9IHtcbiAgYWdlbnREZWZpbml0aW9ucz86IEFnZW50RGVmaW5pdGlvbnNSZXN1bHRcbn1cblxuLyoqXG4gKiBTdGF0dXNOb3RpY2VzIGNvbnRhaW5zIHRoZSBpbmZvcm1hdGlvbiBkaXNwbGF5ZWQgdG8gdXNlcnMgYXQgc3RhcnR1cC4gV2UgaGF2ZVxuICogbW92ZWQgbmV1dHJhbCBvciBwb3NpdGl2ZSBzdGF0dXMgdG8gc3JjL2NvbXBvbmVudHMvU3RhdHVzLnRzeCBpbnN0ZWFkLCB3aGljaFxuICogdXNlcnMgY2FuIGFjY2VzcyB0aHJvdWdoIC9zdGF0dXMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBTdGF0dXNOb3RpY2VzKHtcbiAgYWdlbnREZWZpbml0aW9ucyxcbn06IFByb3BzID0ge30pOiBSZWFjdC5SZWFjdE5vZGUge1xuICBjb25zdCBjb250ZXh0OiBTdGF0dXNOb3RpY2VDb250ZXh0ID0ge1xuICAgIGNvbmZpZzogZ2V0R2xvYmFsQ29uZmlnKCksXG4gICAgYWdlbnREZWZpbml0aW9ucyxcbiAgICBtZW1vcnlGaWxlczogdXNlKGdldE1lbW9yeUZpbGVzKCkpLFxuICB9XG4gIGNvbnN0IGFjdGl2ZU5vdGljZXMgPSBnZXRBY3RpdmVOb3RpY2VzKGNvbnRleHQpXG4gIGlmIChhY3RpdmVOb3RpY2VzLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBudWxsXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxCb3ggZmxleERpcmVjdGlvbj1cImNvbHVtblwiIHBhZGRpbmdMZWZ0PXsxfT5cbiAgICAgIHthY3RpdmVOb3RpY2VzLm1hcChub3RpY2UgPT4gKFxuICAgICAgICA8UmVhY3QuRnJhZ21lbnQga2V5PXtub3RpY2UuaWR9PlxuICAgICAgICAgIHtub3RpY2UucmVuZGVyKGNvbnRleHQpfVxuICAgICAgICA8L1JlYWN0LkZyYWdtZW50PlxuICAgICAgKSl9XG4gICAgPC9Cb3g+XG4gIClcbn1cbiJdLCJtYXBwaW5ncyI6IjtBQUFBLE9BQU8sS0FBS0EsS0FBSyxNQUFNLE9BQU87QUFDOUIsU0FBU0MsR0FBRyxRQUFRLE9BQU87QUFDM0IsU0FBU0MsR0FBRyxRQUFRLFdBQVc7QUFDL0IsY0FBY0Msc0JBQXNCLFFBQVEscUNBQXFDO0FBQ2pGLFNBQVNDLGNBQWMsUUFBUSxzQkFBc0I7QUFDckQsU0FBU0MsZUFBZSxRQUFRLG9CQUFvQjtBQUNwRCxTQUNFQyxnQkFBZ0IsRUFDaEIsS0FBS0MsbUJBQW1CLFFBQ25CLHFDQUFxQztBQUU1QyxLQUFLQyxLQUFLLEdBQUc7RUFDWEMsZ0JBQWdCLENBQUMsRUFBRU4sc0JBQXNCO0FBQzNDLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU8sU0FBQU8sY0FBQUMsRUFBQTtFQUFBLE1BQUFDLENBQUEsR0FBQUMsRUFBQTtFQUF1QjtJQUFBSjtFQUFBLElBQUFFLEVBRWpCLEtBRmlCRyxTQUVqQixHQUZpQixDQUVsQixDQUFDLEdBRmlCSCxFQUVqQjtFQUVELE1BQUFJLEVBQUEsR0FBQVYsZUFBZSxDQUFDLENBQUM7RUFBQSxJQUFBVyxFQUFBO0VBQUEsSUFBQUosQ0FBQSxRQUFBSyxNQUFBLENBQUFDLEdBQUE7SUFFUkYsRUFBQSxHQUFBWixjQUFjLENBQUMsQ0FBQztJQUFBUSxDQUFBLE1BQUFJLEVBQUE7RUFBQTtJQUFBQSxFQUFBLEdBQUFKLENBQUE7RUFBQTtFQUhuQyxNQUFBTyxPQUFBLEdBQXFDO0lBQUFDLE1BQUEsRUFDM0JMLEVBQWlCO0lBQUFOLGdCQUFBO0lBQUFZLFdBQUEsRUFFWnBCLEdBQUcsQ0FBQ2UsRUFBZ0I7RUFDbkMsQ0FBQztFQUNELE1BQUFNLGFBQUEsR0FBc0JoQixnQkFBZ0IsQ0FBQ2EsT0FBTyxDQUFDO0VBQy9DLElBQUlHLGFBQWEsQ0FBQUMsTUFBTyxLQUFLLENBQUM7SUFBQSxPQUNyQixJQUFJO0VBQUE7RUFJVixNQUFBQyxFQUFBLEdBQUF0QixHQUFHO0VBQWUsTUFBQXVCLEVBQUEsV0FBUTtFQUFjLE1BQUFDLEVBQUEsSUFBQztFQUN2QyxNQUFBQyxFQUFBLEdBQUFMLGFBQWEsQ0FBQU0sR0FBSSxDQUFDQyxNQUFBLElBQ2pCLGdCQUFxQixHQUFTLENBQVQsQ0FBQUEsTUFBTSxDQUFBQyxFQUFFLENBQUMsQ0FDM0IsQ0FBQUQsTUFBTSxDQUFBRSxNQUFPLENBQUNaLE9BQU8sRUFDeEIsaUJBQ0QsQ0FBQztFQUFBLElBQUFhLEVBQUE7RUFBQSxJQUFBcEIsQ0FBQSxRQUFBWSxFQUFBLElBQUFaLENBQUEsUUFBQWUsRUFBQTtJQUxKSyxFQUFBLElBQUMsRUFBRyxDQUFlLGFBQVEsQ0FBUixDQUFBUCxFQUFPLENBQUMsQ0FBYyxXQUFDLENBQUQsQ0FBQUMsRUFBQSxDQUFDLENBQ3ZDLENBQUFDLEVBSUEsQ0FDSCxFQU5DLEVBQUcsQ0FNRTtJQUFBZixDQUFBLE1BQUFZLEVBQUE7SUFBQVosQ0FBQSxNQUFBZSxFQUFBO0lBQUFmLENBQUEsTUFBQW9CLEVBQUE7RUFBQTtJQUFBQSxFQUFBLEdBQUFwQixDQUFBO0VBQUE7RUFBQSxPQU5Ob0IsRUFNTTtBQUFBIiwiaWdub3JlTGlzdCI6W119
