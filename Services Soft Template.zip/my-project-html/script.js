
    (() => {
      'use strict';

      //  DOM Elements
      const servicesView = document.getElementById('services-view');
      const calendarPage = document.getElementById('calendar-page');
      const servicesGrid = document.getElementById('services-grid');
      const loadingSpinner = document.getElementById('loading-spinner');
      const errorMessage = document.getElementById('error-message');
      const errorText = document.getElementById('error-text');
      const categoryNav = document.getElementById('category-nav');
      const categoryButtons = document.querySelectorAll('.category-btn');
      const backToServicesBtn = document.getElementById('back-to-services-btn');
      const calendarServiceInfo = document.getElementById('calendar-service-info');

      const bookingModal = document.getElementById('booking-modal');
      const modalContent = document.getElementById('modal-content');
      const cancelBookingBtn = document.getElementById('cancel-booking-btn');
      const confirmBookingBtn = document.getElementById('confirm-booking-btn');
      
      // Removed Contact Form DOM elements and related error elements for now.
      // If you need them back without full JS functionality, let me know.

      //  State
      let allServices = [];
      let selectedService = null;
      let isModalVisible = false;

      //  Utility Functions 
      function showElement(element) {
        element.style.display = 'block';
      }

      function hideElement(element) {
        element.style.display = 'none';
      }

      function toggleModal(show) {
        isModalVisible = show;
        if (show) {
          bookingModal.classList.remove('opacity-0', 'pointer-events-none', 'modal-leave-active', 'modal-leave-to');
          bookingModal.classList.add('modal-enter-active');
          setTimeout(() => { // Trigger nested content animation after modal background is visible
            bookingModal.querySelector('.modal-content').classList.remove('scale-95', 'opacity-0');
          }, 50);
        } else {
          bookingModal.querySelector('.modal-content').classList.add('scale-95', 'opacity-0');
          bookingModal.classList.add('modal-leave-active');
          setTimeout(() => { // Hide modal background after nested content animates out
            bookingModal.classList.remove('modal-enter-active');
            bookingModal.classList.add('opacity-0', 'pointer-events-none', 'modal-leave-to');
          }, 300);
        }
      }

      // These functions are no longer used for contact form but were part of the previous script
      // Keeping them as they don't break functionality
      function clearError(errorElement) {
        // errorElement is now an unused parameter as contact form validation is removed
      }

      function showError(errorElement, message) {
        // errorElement and message are now unused parameters
      }

      function isValidEmail(email) {
        // email is now an unused parameter
        return true; // Always return true as this function is no longer validating contact form email
      }
      
      // This function is defined, but no longer called from the contact form submission.
      // Keeping it here temporarily in case it's needed for other parts of the app.
      function displayMessage(element, message, type = 'info') {
        const classes = {
          'success': 'bg-green-100 border border-green-400 text-green-700',
          'error': 'bg-red-100 border border-red-400 text-red-700',
          'warning': 'bg-yellow-100 border border-yellow-400 text-yellow-700',
          'info': 'bg-blue-100 border border-blue-400 text-blue-700'
        };
        
        // This part would be used if `displayMessage` were called for contact form
        // element.className = `message-enter-from px-4 py-3 rounded text-sm text-center absolute w-full top-0 left-0 ${classes[type]}`;
        // element.innerHTML = message;

        // contactMessageContainer.style.height = `${element.offsetHeight + 16}px`; 
        // contactMessageContainer.style.opacity = '1';

        // setTimeout(() => {
        //   element.classList.remove('message-enter-from');
        //   element.classList.add('message-enter-active');

        //   setTimeout(() => {
        //     element.classList.remove('message-enter-active');
        //     element.classList.add('message-leave-active');
        //     contactMessageContainer.style.height = '0';
        //     contactMessageContainer.style.opacity = '0';
        //     setTimeout(() => {
        //       element.innerHTML = '';
        //     }, 500);
        //   }, 5000);
        // }, 10);
         console.log(`Message (type: ${type}): ${message}`); // Log message to console instead
      }

      //  Service Data Simulation 
      const servicesData = [
        { id: 'h1', name: 'Signature Haircut', description: 'A personalized cut and style tailored to your features.', price: 65, duration: 60, category: 'haircut', imageUrl: 'https://images.unsplash.com/photo-1596465449767-f4728f39572c?w=800&auto=format&fit=crop' },
        { id: 'h2', name: 'Men\'s Haircut', description: 'Classic or contemporary cuts for men, including a quick wash.', price: 40, duration: 45, category: 'haircut', imageUrl: 'https://images.unsplash.com/photo-1621607512214-de8256a73507?w=800&auto=format&fit=crop' },
        { id: 'h3', name: 'Kid\'s Haircut', description: 'Fun and professional haircuts for children under 10.', price: 30, duration: 30, category: 'haircut', imageUrl: 'https://images.unsplash.com/photo-1602492193540-5bfa26002f23?w=800&auto=format&fit=crop' },
        { id: 'c1', name: 'Full Highlights', description: 'Complete hair lightening with foils for a sun-kissed look.', price: 180, duration: 180, category: 'coloring', imageUrl: 'https://images.unsplash.com/photo-1603505886361-b1e9e0d16be9?w=800&auto=format&fit=crop' },
        { id: 'c2', name: 'Balayage', description: 'Hand-painted highlights for a natural, graduated effect.', price: 220, duration: 240, category: 'coloring', imageUrl: 'https://images.unsplash.com/photo-1579782548480-1a6fbf8c5936?w=800&auto=format&fit=crop' },
        { id: 'c3', name: 'Root Touch-Up', description: 'Covering regrowth to extend your color vibrancy.', price: 90, duration: 120, category: 'coloring', imageUrl: 'https://images.unsplash.com/photo-1604514628550-327c19f5ad85?w=800&auto=format&fit=crop' },
        { id: 's1', name: 'Blowout & Style', description: 'Professional wash, blow-dry, and styling for any occasion.', price: 50, duration: 60, category: 'styling', imageUrl: 'https://images.unsplash.com/photo-1510006240085-c0529d914751?w=800&auto=format&fit=crop' },
        { id: 's2', name: 'Updo/Event Hair', description: 'Elegant updos or intricate styles for weddings and special events.', price: 100, duration: 90, category: 'styling', imageUrl: 'https://images.unsplash.com/photo-1522338148-e4b77f917538?w=800&auto=format&fit=crop' },
        { id: 't1', name: 'Deep Conditioning', description: 'Intensive treatment to restore moisture and shine.', price: 45, duration: 30, category: 'treatment', imageUrl: 'https://images.unsplash.com/photo-1595476316719-74e2d3340578?w=800&auto=format&fit=crop' },
        { id: 't2', name: 'Keratin Treatment', description: 'Smooths frizz and adds brilliant shine for several months.', price: 250, duration: 180, category: 'treatment', imageUrl: 'https://images.unsplash.com/photo-1596465439401-447a1670f3f2?w=800&auto=format&fit=crop' },
      ];

      function fetchServices() {
        showElement(loadingSpinner);
        hideElement(errorMessage);
        servicesGrid.innerHTML = ''; // Clear previous services

        return new Promise(resolve => {
          setTimeout(() => { // Simulate API call delay
            hideElement(loadingSpinner);
            // Simulate success or failure
            if (Math.random() > 0.1) { // 90% chance of success
              allServices = servicesData;
              resolve(allServices);
            } else {
              errorText.textContent = 'Failed to load services. Please check your connection.';
              showElement(errorMessage);
              resolve([]); // Return empty array on failure
            }
          }, 1000);
        });
      }

      function renderServices(servicesToRender) {
        servicesGrid.innerHTML = ''; // Clear current services
        if (servicesToRender.length === 0 && !loadingSpinner.style.display === 'block') {
          servicesGrid.innerHTML = '<p class="col-span-full text-center text-gray-500 text-lg">No services found for this category.</p>';
          return;
        }

        servicesToRender.forEach(service => {
          const serviceCard = `
            <div class="bg-white rounded-lg shadow-lg overflow-hidden flex flex-col card-hover animate-slideUpIn">
              <img src="${service.imageUrl}" alt="${service.name}" class="w-full h-48 object-cover">
              <div class="p-6 flex-grow flex flex-col">
                <h3 class="text-2xl font-semibold text-pink-primary mb-2">${service.name}</h3>
                <p class="text-gray-600 mb-4 flex-grow">${service.description}</p>
                <div class="flex items-center justify-between mt-auto pt-4 border-t border-gray-100">
                  <span class="text-xl font-bold text-gray-800">£${service.price}</span>
                  <button data-service-id="${service.id}" class="btn-primary select-service-btn">Book Now</button>
                </div>
              </div>
            </div>
          `;
          servicesGrid.insertAdjacentHTML('beforeend', serviceCard);
        });
      }

      function filterServices(category) {
        categoryButtons.forEach(btn => btn.classList.remove('bg-gray-100', 'text-pink-primary', 'border-pink-primary'));
        const currentBtn = document.querySelector(`[data-category="${category}"]`);
        if (currentBtn) {
          currentBtn.classList.add('bg-gray-100', 'text-pink-primary', 'border-pink-primary');
        }

        const filtered = category === 'all' ? allServices : allServices.filter(service => service.category === category);
        renderServices(filtered);
      }

      function showCalendarPage(service) {
        selectedService = service;
        const infoHtml = `
          <h3 class="text-3xl font-bold text-gray-800 mb-2">${service.name}</h3>
          <p class="text-lg text-gray-600">${service.description}</p>
          <p class="text-2xl font-bold text-pink-primary mt-4">£${service.price} <span class="text-gray-500 text-base font-normal">(${service.duration} min)</span></p>
          <div class="mt-4 flex justify-center space-x-4">
            <button id="book-this-service-btn" class="btn-primary">Choose this Time</button>
            <button id="back-to-services-detail-btn" class="btn-secondary">Choose another Service</button>
          </div>
        `;
        calendarServiceInfo.innerHTML = infoHtml;

        // Simulate a simple calendar visualization
        const calendarHtml = `
          <div class="bg-blue-50 p-6 rounded-lg shadow-inner mt-6">
            <p class="text-lg text-blue-800 font-semibold mb-4 text-center">Select Your Preferred Date & Time</p>
            <div class="grid grid-cols-7 gap-2 text-center text-gray-700 font-medium mb-4">
              <span>Sun</span><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span>
            </div>
            <div class="grid grid-cols-7 gap-2">
              ${Array.from({ length: new Date(2024, 7, 0).getDate() }).map((_, i) => `
                <button
                  class="calendar-day p-2 rounded-lg hover:bg-pink-100 transition-colors duration-200 cursor-pointer
                  ${new Date().getDate() === (i + 1) ? 'bg-pink-primary text-white font-bold' : 'bg-gray-100'}"
                  data-date="2024-07-${i + 1}"
                >
                  ${i + 1}
                </button>
              `).join('')}
            </div>
            <div class="mt-6">
              <label for="time-slot" class="block text-gray-700 text-lg font-semibold mb-2 text-center">Available Time Slots</label>
              <select id="time-slot" class="w-full p-3 border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-pink-primary focus:border-transparent transition-all duration-200">
                <option value="">-- Select a Time --</option>
                <option value="09:00">09:00 AM</option>
                <option value="10:00">10:00 AM</option>
                <option value="11:00">11:00 AM</option>
                <option value="13:00">01:00 PM</option>
                <option value="14:00">02:00 PM</option>
                <option value="15:00">03:00 PM</option>
                <option value="16:00">04:00 PM</option>
              </select>
            </div>
          </div>
        `;
        document.getElementById('calendar-visualization-area').innerHTML = calendarHtml;

        servicesView.style.opacity = '0';
        servicesView.classList.add('pointer-events-none');
        calendarPage.classList.remove('hidden');
        setTimeout(() => {calendarPage.style.opacity = '1';}, 10); // Small delay for fade in
      }

      function showServicesView() {
        calendarPage.style.opacity = '0';
        setTimeout(() => {
          calendarPage.classList.add('hidden');
          servicesView.style.opacity = '1';
          servicesView.classList.remove('pointer-events-none');
        }, 300); // Match transition duration
      }

      function prepareBookingModal(service) {
        if (!service) return; // Should not happen if called correctly
        modalContent.innerHTML = `
          <p class="text-gray-700">Service: <strong class="text-pink-primary">${service.name}</strong></p>
          <p class="text-gray-700">Price: <strong class="text-gray-800">£${service.price}</strong></p>
          <p class="text-gray-700">Duration: <strong class="text-gray-800">${service.duration} minutes</strong></p>
          <div class="mt-4 p-3 bg-gray-50 rounded-md">
            <label for="client-name" class="block text-gray-700 text-sm font-semibold mb-2">Your Name</label>
            <input type="text" id="client-name" class="w-full px-3 py-2 border border-gray-300 rounded-md" placeholder="e.g., Jane Doe" required>
            <p id="client-name-modal-error" class="text-red-500 text-xs mt-1 hidden">Your name is required.</p>

            <label for="client-email" class="block text-gray-700 text-sm font-semibold mt-3 mb-2">Your Email</label>
            <input type="email" id="client-email" class="w-full px-3 py-2 border border-gray-300 rounded-md" placeholder="e.g., jane@example.com" required>
            <p id="client-email-modal-error" class="text-red-500 text-xs mt-1 hidden">A valid email is required.</p>
          </div>
        `;
        toggleModal(true);
      }

      function confirmBooking() {
        const clientNameInput = document.getElementById('client-name');
        const clientEmailInput = document.getElementById('client-email');
        const clientNameError = document.getElementById('client-name-modal-error');
        const clientEmailError = document.getElementById('client-email-modal-error');

        let isValid = true;
        // The original clearError is still here but takes a `document.getElementById` as an argument
        // For the modal these local error elements are just hidden.
        clientNameError.classList.add('hidden'); 
        clientEmailError.classList.add('hidden'); 

        if (!clientNameInput.value.trim()) {
          clientNameError.textContent = 'Your name is required.';
          clientNameError.classList.remove('hidden');
          isValid = false;
        }
        // Using a basic email validation check here again,
        // as the global isValidEmail function was simplified to "true"
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!clientEmailInput.value.trim() || !emailRegex.test(clientEmailInput.value)) {
          clientEmailError.textContent = 'A valid email is required.';
          clientEmailError.classList.remove('hidden');
          isValid = false;
        }

        if (!isValid) return;

        // Simulate booking confirmation
        console.log('Booking Confirmed:', {
          service: selectedService,
          clientName: clientNameInput.value,
          clientEmail: clientEmailInput.value,
          // Add selected date and time from calendar here if implemented
        });

        toggleModal(false);
        // Maybe show a success message on the main page or redirect
        alert('Booking successfully confirmed for ' + selectedService.name + '!');
      }

      //  Event Listeners 
      servicesGrid.addEventListener('click', (event) => {
        const button = event.target.closest('.select-service-btn');
        if (button) {
          const serviceId = button.dataset.serviceId;
          const service = allServices.find(s => s.id === serviceId);
          if (service) {
            showCalendarPage(service);
          }
        }
      });

      categoryNav.addEventListener('click', (event) => {
        const button = event.target.closest('.category-btn');
        if (button) {
          filterServices(button.dataset.category);
        }
      });

      backToServicesBtn.addEventListener('click', showServicesView);

      // Event delegation for the dynamically injected calendar buttons
      document.getElementById('calendar-visualization-area').addEventListener('click', (event) => {
        const bookThisService = event.target.closest('#book-this-service-btn');
        const backToServicesDetail = event.target.closest('#back-to-services-detail-btn');
        const calendarDay = event.target.closest('.calendar-day');

        if (bookThisService && selectedService) {
          prepareBookingModal(selectedService);
        } else if (backToServicesDetail) {
          showServicesView();
        } else if (calendarDay) {
          document.querySelectorAll('.calendar-day').forEach(day => {
            day.classList.remove('bg-pink-primary', 'text-white', 'font-bold');
            day.classList.add('bg-gray-100');
          });
          calendarDay.classList.remove('bg-gray-100');
          calendarDay.classList.add('bg-pink-primary', 'text-white', 'font-bold');
          console.log('Selected Date:', calendarDay.dataset.date);
          // Here you'd store the selected date in 'selectedService' or a separate state
        }
      });

      cancelBookingBtn.addEventListener('click', () => toggleModal(false));
      confirmBookingBtn.addEventListener('click', confirmBooking);

      bookingModal.addEventListener('click', (event) => {
        if (event.target === bookingModal) {
          toggleModal(false);
        }
      });

      //  Contact Form Functionality 
      // This section was completely removed as requested.
      // The HTML elements for the contact form are still present, but they have no
      // JavaScript functionality attached to them.
      // Form submission will trigger a default browser action (page reload).

      //  Initialization 
      async function initializeApp() {
        await fetchServices();
        filterServices('all'); // Display all services by default
        categoryButtons[0].classList.add('bg-gray-100', 'text-pink-primary', 'border-pink-primary');
      }

      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeApp);
      } else {
        initializeApp();
      }
    })();
  