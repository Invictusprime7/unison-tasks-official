# my-project

Generated with AI Web Builder.

## Files
- index.html - Main HTML file
- styles.css - Stylesheet
- script.js - JavaScript functionality

## Usage
Open index.html in your browser.