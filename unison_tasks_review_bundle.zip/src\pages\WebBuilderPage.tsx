import { WebBuilder } from "@/components/creatives/WebBuilder";

const WebBuilderPage = () => {
  return (
    <div className="h-screen w-full">
      <WebBuilder />
    </div>
  );
};

export default WebBuilderPage;
