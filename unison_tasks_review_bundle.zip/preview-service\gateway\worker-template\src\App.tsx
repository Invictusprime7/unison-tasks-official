export default function App() {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold">Preview Ready</h1>
      <p className="text-gray-600">Waiting for content...</p>
    </div>
  );
}
