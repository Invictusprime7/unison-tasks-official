export function Toaster() {
  // Radix ToastProvider disabled to avoid runtime conflict; using Sonner instead.
  return null;
}
